'use strict';
// var path = require('path');
// var server = require(path.resolve(__dirname,'../..'));
// var datasource = server.dataSource.loopback;

module.exports = function(MarchantUsers) {

    MarchantUsers.validation = function(data,cb){
    var accNo = data.accountNo;
    var mobno = data.mobnom;
    console.log(accNo);
    MarchantUsers.findOne({where:{accountNumber : accNo,mobileNumber : mobno}}, function(err,res){
      if (res===null){
          cb(null,{"message" : "invalid account" , "status" : "fail"})
          return cb;
      }else{
          var response = {
              "AccountNumber" : res.accountNumber,
              "cust_Id" : res.custId,
              "message" : "Validation done",
              "Status" : "Success"
          };
          cb(null,response)
      }
    })
}

MarchantUsers.remoteMethod('validation',{
    http: {path:'/merchants_test', verb:'post'},
    accepts:{arg:'data', type:'object', http:{source:'body'}},
    returns:{arg:'resultObjects',type:['event'],root: true}
});

};